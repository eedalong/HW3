import numpy as np
from matplotlib import pyplot as plt
import math
import os
from typing import Dict, List
import time
class DataLoader:
    def __init__(self, folder_path="data/"):
        self.folder_path = folder_path

    def loadIdx(self)->(Dict,Dict):
        # load user idx
        user_idx = {}
        with open(os.path.join(self.folder_path, "users.txt")) as user_file:
            for index, user_id in enumerate(user_file):
                user_id = user_id[:-1]
                user_idx[user_id] = index


        # load movie idx
        movie_idx = {}
        with open(os.path.join(self.folder_path, "movie_titles.txt")) as movie_file:
            for index, movie_id in enumerate(movie_file):
                movie_id = movie_id.split(",")[0]
                movie_idx[movie_id] = index
        return user_idx, movie_idx

    def loadData(self, file_name)->(str, List):
        with open(os.path.join(self.folder_path, file_name)) as data_file:

            firstLine = next(data_file)
            data = firstLine.split(" ")
            user_id = data[0]
            res = [data[1:]]
            for line in data_file:
                data = line.split(" ")
                if data[0] != user_id:
                    yield user_id, res
                    res = [data[1:]]
                    user_id = data[0]
                else:
                    res.append(data[1:])

class CollabrotiveFilter:
    def measure(self, prediction, real_value):
        self.loss += np.square(prediction-real_value)


    def __init__(self, folder=""):
        self.train_data = np.load(os.path.join(folder, "train_mat.npy"))
        self.test_data = np.load(os.path.join(folder, "test_mat.npy"))
        self.loss = 0.0
        self.user_idx, self.movie_idx = DataLoader().loadIdx()
        self.sims = np.zeros((len(self.user_idx), len(self.user_idx)))

    def PearsonTestCase(self):
        vec1 = np.array([4.0,0,0,5,1,0,0])
        vec2 = np.array([5.0,5,4,0,0,0,0])
        assert np.round(self.calPearson(vec1, vec2), 3) == 0.092

    def calPearson(self, vec1, vec2):
        epsilon = 1e-10
        mean_a = np.mean(vec1[vec1!=0])
        mean_b = np.mean(vec2[vec2!=0])
        vec1[vec1 == 0] = mean_a
        vec2[vec2 == 0] = mean_b
        vec1 -= np.mean(vec1)
        vec2 -= np.mean(vec2)
        return np.dot(vec1, vec2) / (np.sqrt(np.dot(vec1, vec1)) * np.sqrt(np.dot(vec2, vec2)) + epsilon)

    def PearsonSim(self, idx1, idx2):

        vec1 = np.copy(self.train_data[idx1])
        vec2 = np.copy(self.train_data[idx2])
        sim = self.calPearson(vec1, vec2)

        return sim

    def cosSimTestCase(self):
        self.train_data = np.array([[4.0, 0, 0, 5, 1, 0, 0],[5.0, 5, 4, 0, 0, 0, 0]])
        self.test_data = np.array([[0.0, 5, 4, 0, 0, 0, 0],[0.0, 0,0, 5, 1, 0, 0]])
        self.cosSim()
        print(self.sims)
        assert self.sims[0][0] == 0

    def cosSim(self):
        product = self.train_data.dot(self.train_data.transpose())
        square_sum = self.train_data * self.train_data
        square_sum = np.sum(square_sum, axis=1)
        square_sum = np.sqrt(square_sum)
        left = np.array([square_sum]).transpose()
        right = np.array([square_sum])
        square_sum = left.dot(right)
        self.sims = product / square_sum
        self.sims[range(self.sims.shape[0]), range(self.sims.shape[0])] = 0



    def calSim(self):
        for idx1 in range(len(self.user_idx)):
            for idx2 in range(idx1+1, len(self.user_idx)):
                sim = self.PearsonSim(idx1, idx2)
                self.sims[idx1][idx2] = sim
                self.sims[idx2][idx1] = sim


    def test(self):
        start_time = time.time()
        self.cosSim()
        print(f"SIM CALCULATE FINISHED")
        predict_res = self.sims.dot(self.train_data)
        contribution = np.zeros(self.test_data.shape)
        contribution[self.train_data !=0] = 1
        contirbution = self.sims.dot(contribution)
        predict_res = predict_res  / (contirbution + 1e-10)

        ones = np.ones(self.test_data.shape)
        predict_res[self.test_data == 0] = 0
        ones[self.test_data == 0] = 0
        diff = predict_res - self.test_data
        diff *= diff
        square_error = np.sum(diff)
        rmse = square_error / np.sum(ones)
        end_time = time.time()
        print(f"check rmse = {rmse}, consuming time = {end_time-start_time}")


class LatentFactorModel:
    def __init__(self, k=50, lamda=0.01):
        self.train_data = np.load("train_mat.npy")
        self.A = np.zeros(self.train_data.shape)
        self.A[self.train_data!=0] = 1
        self.test_data = np.load("test_mat.npy")
        self.B = np.zeros(self.test_data.shape)
        self.B[self.test_data !=0] = 1

        self.k = k
        self.lamda = lamda
        self.U = np.random.uniform(0, 2 * math.sqrt(5/(k*k)), (self.train_data.shape[0], k))
        self.V = np.random.uniform(0, 2* math.sqrt(5/(k*k)), (self.train_data.shape[1], k))
        self.prediction = np.zeros(self.train_data.shape)
        self.J = 0
        self.alpha = 1e-4
        self.max_steps = 100

    def Frobenius2(self, mat):
        return np.sum(mat * mat)


    def targetFunction(self):
        self.prediction = self.U.dot(self.V.transpose())
        self.J = 0.5 * self.Frobenius2(self.A * (self.train_data - self.prediction)) \
            + self.lamda * self.Frobenius2(self.U) + self.lamda * self.Frobenius2(self.V)

    def diff(self):
        diff = self.A * (self.prediction - self.train_data)
        diffU = diff.dot(self.V) + 2 * self.lamda * self.U
        diffV = diff.transpose().dot(self.U) + 2 * self.lamda * self.V
        return diffU, diffV


    def RMSEOnTrain(self):
        res = self.A * (self.prediction - self.train_data)
        rmse = np.sqrt(np.sum(res * res) / np.sum(self.A))
        return rmse

    def RMSEOnTest(self):
        res = self.B * (self.prediction - self.test_data)
        rmse = np.sqrt(np.sum(res * res ) / np.sum(self.B))
        return rmse

    def train(self):
        target_functions = []
        rmse_on_test = []
        rmse_train = 0
        rmse_test = 0
        for step in range(self.max_steps):
            self.targetFunction()
            diffU, diffV = self.diff()
            self.U -= self.alpha * diffU
            self.V -= self.alpha * diffV
            rmse_train = self.RMSEOnTrain()
            rmse_test = self.RMSEOnTest()
            target_functions.append(self.J)
            rmse_on_test.append(rmse_test)
            print(f"step {step}:check rmse on train = {rmse_train} \tcheck rmse on test = {rmse_test} \t and target function = {self.J}")

        plt.clf()
        plt.plot(list(range(self.max_steps)), rmse_on_test, label="RMSE on test")
        plt.savefig(f"rmse_curve_{self.k}_{self.lamda}.png")

        plt.clf()
        plt.plot(list(range(self.max_steps)), target_functions, label="target Function")
        plt.savefig(f"target_function_{self.k}_{self.lamda}.png")

        return rmse_train, rmse_test

if __name__ == "__main__":

    model = LatentFactorModel()
    model.train()
    '''
    res = {}

    ks = [10, 50, 100]
    lamdas = [0.001, 0.01, 0.1]
    for k in ks:
        for lamda in lamdas:
            model = LatentFactorModel(k=k, lamda=lamda)
            model.train()
            rmse_test = model.RMSEOnTest()
            res[f"{k}_{lamda}"] = rmse_test
    print("check all res \t", res)
    '''

